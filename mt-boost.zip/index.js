exports.greeting = function() {
	console.log('mt-boost');
}
